package laboratorio;

public class Patin {
    public void girarDerecha(int grados) {
        System.out.println("Giro de "+grados+" grados a la derecha");
    }
    public void girarIzquierda(int grados) {
        System.out.println("Giro de "+grados+" grados a la izquierda");
    }

}
