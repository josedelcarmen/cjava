package laboratorio;

public class NaveAerea {
    protected char direccion;
    protected int altura;
    public void setDireccion(char direccion) {
        this.direccion= direccion;
    }
    public char getDireccion() {
        return this.direccion;
    }
}
